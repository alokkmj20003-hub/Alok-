# Alok Voice Chat — Android starter project

यह एक शुरुआती Android/Kotlin प्रोजेक्ट है जिसमें Agora RTC से वॉइस चैनल जॉइन करना, माइक म्यूट/अनम्यूट करना और रूम छोड़ना शामिल है।

## महत्वपूर्ण सीमा
यह अभी पूरा production app नहीं है। इसमें यूज़र अकाउंट/OTP, प्रोफाइल फोटो, रूम डायरेक्टरी, चैट, गिफ्ट/कॉइन, मॉडरेशन बैकएंड या APK शामिल नहीं हैं। इस ZIP में Android source code है; APK अभी build नहीं किया गया है।

## Android मोबाइल से इस्तेमाल
1. ZIP को डाउनलोड करके Extract करें।
2. Android पर ऐसा IDE/Gradle environment खोलें जो Android Gradle Plugin 8.7.3 और Kotlin 2.0.21 सपोर्ट करता हो।
3. Extract किए गए `AlokVoiceChat` फ़ोल्डर को Android project के रूप में खोलें।
4. इंटरनेट चालू रखकर Gradle Sync पूरा होने दें। पहली बार SDK/dependencies डाउनलोड होंगे।
5. ऐप चलाएँ और Agora App ID डालें।
6. Agora Console से उसी channel name के लिए वैध temporary token बनाएँ और ऐप में डालें, यदि आपका प्रोजेक्ट token मांगता है।
7. दूसरे डिवाइस पर भी वही App ID, channel name और वैध token इस्तेमाल करें; दोनों को अलग UID देना production में बेहतर है। इस starter में SDK UID `0` ऑटो-जनरेट करने देता है।

## सुरक्षा
- App Certificate, API secret या स्थायी secret ऐप में कभी न रखें।
- Production app में token अपने सुरक्षित backend server से बनवाएँ; ऐप में स्थायी secret नहीं होना चाहिए।
- Blank token केवल तभी काम कर सकता है जब Agora project की configuration इसकी अनुमति देती हो। Secure project में valid token चाहिए।
- App ID को इस source code में hard-code नहीं किया गया है; इसे ऐप के अंदर दर्ज किया जाता है।

## SDK
Agora RTC Android SDK dependency `io.agora.rtc:full-sdk:4.5.0` है। यदि sync में version/repository की समस्या आए, तो Agora की आधिकारिक release notes और quickstart देखकर SDK version अपडेट करें:
https://docs.agora.io/en/realtime-media/rtc/get-started-sdk?platform=android

## Build की ज़रूरत
इस प्रोजेक्ट को APK बनाने के लिए Android SDK, compatible JDK/Gradle और इंटरनेट चाहिए। यह ZIP अपने आप फोन में install होने वाली APK नहीं है।
