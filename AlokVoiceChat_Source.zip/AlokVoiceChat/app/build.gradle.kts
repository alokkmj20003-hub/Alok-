plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alokvoicechat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.alokvoicechat"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    // Agora RTC voice/video SDK. If Agora publishes a newer compatible release,
    // update this version after checking the official release notes.
    implementation("io.agora.rtc:full-sdk:4.5.0")
}
