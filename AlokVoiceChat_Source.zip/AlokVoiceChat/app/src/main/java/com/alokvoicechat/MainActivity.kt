package com.alokvoicechat

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.ChannelProfile
import io.agora.rtc2.ClientRoleOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig

class MainActivity : Activity() {
    private var rtcEngine: RtcEngine? = null
    private var joined = false
    private var muted = false

    private lateinit var appIdInput: EditText
    private lateinit var tokenInput: EditText
    private lateinit var roomInput: EditText
    private lateinit var statusText: TextView
    private lateinit var joinButton: Button
    private lateinit var leaveButton: Button
    private lateinit var muteButton: Button

    private val handler = object : IRtcEngineEventHandler() {
        override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
            runOnUiThread {
                joined = true
                statusText.text = "रूम में जुड़ गए: ${channel ?: ""}  | UID: $uid"
                joinButton.isEnabled = false
                leaveButton.isEnabled = true
                muteButton.isEnabled = true
            }
        }

        override fun onUserJoined(uid: Int, elapsed: Int) {
            runOnUiThread {
                statusText.text = statusText.text.toString() + "\nयूज़र जुड़ा: $uid"
            }
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            runOnUiThread {
                statusText.text = statusText.text.toString() + "\nयूज़र बाहर गया: $uid"
            }
        }

        override fun onError(err: Int) {
            runOnUiThread {
                statusText.text = "Agora त्रुटि: $err. App ID/Token/नेटवर्क जाँचें।"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestMicPermissionIfNeeded()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            setBackgroundColor(Color.rgb(17, 18, 38))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        page.addView(scroll, ViewGroup.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = "Alok Voice Chat"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(8))
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "अपना रूम बनाएँ या उसी रूम नाम से दोस्तों के साथ जुड़ें"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(20))
        }
        content.addView(subtitle, matchWrap())

        appIdInput = field("Agora App ID यहाँ डालें")
        tokenInput = field("Agora temporary Token यहाँ डालें (सुरक्षित प्रोजेक्ट में आवश्यक)")
        roomInput = field("रूम का नाम, जैसे alok-room-01")
        content.addView(label("Agora App ID"))
        content.addView(appIdInput, matchWrap())
        content.addView(label("Agora Token"))
        content.addView(tokenInput, matchWrap())
        content.addView(label("Room Name"))
        content.addView(roomInput, matchWrap())

        joinButton = button("रूम जॉइन करें")
        joinButton.setOnClickListener { joinRoom() }
        content.addView(joinButton, matchWrap())

        muteButton = button("माइक म्यूट करें")
        muteButton.isEnabled = false
        muteButton.setOnClickListener { toggleMute() }
        content.addView(muteButton, matchWrap())

        leaveButton = button("रूम छोड़ें")
        leaveButton.isEnabled = false
        leaveButton.setOnClickListener { leaveRoom() }
        content.addView(leaveButton, matchWrap())

        statusText = TextView(this).apply {
            text = "स्थिति: रूम में शामिल नहीं हैं"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, dp(18), 0, dp(18))
        }
        content.addView(statusText, matchWrap())

        val note = TextView(this).apply {
            text = "ध्यान दें: यह शुरुआती वॉइस-रूम प्रोटोटाइप है। इसमें अभी अकाउंट, प्रोफाइल फोटो, रूम सूची, चैट, मॉडरेटर और सर्वर-आधारित Token सिस्टम शामिल नहीं हैं।"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(14), 0, dp(20))
        }
        content.addView(note, matchWrap())
        setContentView(page)
    }

    private fun joinRoom() {
        if (!hasMicPermission()) {
            requestMicPermissionIfNeeded()
            return
        }
        val appId = appIdInput.text.toString().trim()
        val tokenText = tokenInput.text.toString().trim()
        val room = roomInput.text.toString().trim()

        if (appId.isBlank() || room.isBlank()) {
            toast("App ID और Room Name भरें")
            return
        }
        if (appId.contains(" ")) {
            toast("App ID सही कॉपी करें")
            return
        }

        try {
            if (rtcEngine == null) {
                val config = RtcEngineConfig().apply {
                    mContext = applicationContext
                    mAppId = appId
                    mEventHandler = handler
                }
                rtcEngine = RtcEngine.create(config)
                rtcEngine?.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION)
                rtcEngine?.enableAudio()
            }

            val options = ChannelMediaOptions().apply {
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                publishMicrophoneTrack = true
                autoSubscribeAudio = true
            }
            statusText.text = "रूम से जुड़ रहे हैं…"
            joinButton.isEnabled = false
            // A blank token works only if the Agora project is configured to allow it.
            // For a secured project, paste a valid temporary token for this exact channel.
            val token = tokenText.ifBlank { null }
            val result = rtcEngine?.joinChannel(token, room, 0, options) ?: -1
            if (result < 0) {
                joinButton.isEnabled = true
                statusText.text = "रूम जॉइन नहीं हुआ। Token, App ID और channel जाँचें। Code: $result"
            }
        } catch (e: Exception) {
            joinButton.isEnabled = true
            statusText.text = "सेटअप में त्रुटि: ${e.message ?: "unknown"}"
        }
    }

    private fun toggleMute() {
        val engine = rtcEngine ?: return
        muted = !muted
        engine.muteLocalAudioStream(muted)
        muteButton.text = if (muted) "माइक अनम्यूट करें" else "माइक म्यूट करें"
        statusText.text = if (muted) "आपका माइक म्यूट है" else "आपका माइक चालू है"
    }

    private fun leaveRoom() {
        rtcEngine?.leaveChannel()
        joined = false
        muted = false
        joinButton.isEnabled = true
        leaveButton.isEnabled = false
        muteButton.isEnabled = false
        muteButton.text = "माइक म्यूट करें"
        statusText.text = "आपने रूम छोड़ दिया"
    }

    private fun requestMicPermissionIfNeeded() {
        if (!hasMicPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 101)
        }
    }

    private fun hasMicPermission(): Boolean =
        Build.VERSION.SDK_INT < 23 ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            toast("वॉइस रूम के लिए माइक्रोफोन की अनुमति ज़रूरी है")
        }
    }

    override fun onDestroy() {
        try {
            rtcEngine?.leaveChannel()
            RtcEngine.destroy()
            rtcEngine = null
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.GRAY)
        setTextColor(Color.WHITE)
        textSize = 14f
        setSingleLine(true)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(Color.rgb(38, 40, 66))
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun button(textValue: String) = Button(this).apply {
        text = textValue
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(88, 70, 210))
        setPadding(dp(10), dp(8), dp(10), dp(8))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
